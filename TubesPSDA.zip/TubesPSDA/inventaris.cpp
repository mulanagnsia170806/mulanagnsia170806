#include "inventaris.h"

Inventaris::Inventaris(QString nama, int jumlah, QString tanggal)
    : namaBarang(nama), jumlah(jumlah), tanggalDitambahkan(tanggal) {}
